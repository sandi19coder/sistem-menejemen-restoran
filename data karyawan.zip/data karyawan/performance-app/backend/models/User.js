const mongoose = require('mongoose');

const UserSchema = new mongoose.Schema({
    name: { type: String, required: true },
    email: { type: String, required: true, unique: true },
    password: { type: String, required: true },
    role: { type: String, enum: ['admin', 'employee'], default: 'employee' },
    position: { type: String, default: 'Staff' },
    totalScore: { type: Number, default: 0 },
    rank: { type: Number, default: 0 },
    joinedAt: { type: Date, default: Date.now },
});

module.exports = mongoose.model('User', UserSchema);
